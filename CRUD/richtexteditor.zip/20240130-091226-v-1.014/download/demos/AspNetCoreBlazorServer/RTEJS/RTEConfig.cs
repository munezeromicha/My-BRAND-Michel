﻿namespace RTEJS_BlazorServer.RTEJS
{
	public class RTEConfig
	{
		public string? toolbar { get; set; }

		public string? toolbarMobile { get; set; }

		public string? skin { get; set; }

		public int? maxHTMLLength { get; set; }

		public string? editorResizeMode { get; set; }

		public string? pasteMode { get; set; }

		public string? enterKeyTag { get; set;}
	}
}
